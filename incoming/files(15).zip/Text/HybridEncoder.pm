package Text::HybridEncoder;

use strict;
use warnings;
use Encode qw(encode decode);
use MIME::Base32 qw(encode_base32 decode_base32);
use MIME::Base64 qw(encode_base64 decode_base64);

# Constructor
sub new {
    my ($class, %args) = @_;
    my $self = {
        templates => $args{templates} // {},
        binary_data => $args{binary_data} // {},
    };
    bless $self, $class;
    return $self;
}

# Add a new template
sub add_template {
    my ($self, $name, $pattern) = @_;
    $self->{templates}->{$name} = $pattern;
}

# Add binary data
sub add_binary_data {
    my ($self, $name, $data) = @_;
    $self->{binary_data}->{$name} = $data;
}

# Encode data stream using templates and dynamic encoding
sub encode_stream {
    my ($self, $data_stream) = @_;

    my $encoded_stream = $data_stream;

    # Replace patterns with template references using the best encoding
    while (my ($name, $pattern) = each %{$self->{templates}}) {
        my $utf7_encoded = encode('UTF-7', $pattern);
        my $utf8_encoded = encode('UTF-8', $pattern);
        my $best_encoded = length($utf7_encoded) < length($utf8_encoded) ? $utf7_encoded : $utf8_encoded;
        
        $encoded_stream =~ s/\Q$pattern\E/$best_encoded/g;
    }

    # Encode binary data
    while (my ($name, $data) = each %{$self->{binary_data}}) {
        my $base32_encoded = encode_base32($data);
        my $utf7_encoded = encode('UTF-7', $base32_encoded);
        $encoded_stream .= " $name:$utf7_encoded";
    }

    return $encoded_stream;
}

# Decode data stream using templates and dynamic decoding
sub decode_stream {
    my ($self, $encoded_stream) = @_;

    my $decoded_stream = $encoded_stream;

    # Replace template references with original patterns
    while (my ($name, $pattern) = each %{$self->{templates}}) {
        my $utf7_encoded = encode('UTF-7', $pattern);
        my $utf8_encoded = encode('UTF-8', $pattern);
        
        $decoded_stream =~ s/\Q$utf7_encoded\E/$pattern/g;
        $decoded_stream =~ s/\Q$utf8_encoded\E/$pattern/g;
    }

    # Decode binary data
    foreach my $name (keys %{$self->{binary_data}}) {
        if ($decoded_stream =~ /$name:(\+.*?) /) {
            my $encoded_data = $1;
            my $base32_encoded = decode('UTF-7', $encoded_data);
            my $data = decode_base32($base32_encoded);
            $self->{binary_data}->{$name} = $data;
        }
    }

    return $decoded_stream;
}

# Save templates to a file
sub save_templates {
    my ($self, $file) = @_;
    store($self->{templates}, $file);
}

# Load templates from a file
sub load_templates {
    my ($self, $file) = @_;
    $self->{templates} = retrieve($file);
}

# Save binary data to a file
sub save_binary_data {
    my ($self, $file) = @_;
    store($self->{binary_data}, $file);
}

# Load binary data from a file
sub load_binary_data {
    my ($self, $file) = @_;
    $self->{binary_data} = retrieve($file);
}

1;