# Archive Inventory Report

**Generated**: Thu Oct  2 21:28:07 2025

---

## Summary

- Archive files found: 155
- Repository files: 22

---

## ⚠️  Files Only in Archives (Potentially Uncommitted)

**Count**: 134 files

- `0020/ANALYSIS_SUMMARY.md` (4115 bytes)
- `0020/CLONED_REPO_ANALYSIS.md` (4720 bytes)
- `0020/INSTALLATION_TEST_RESULTS.md` (6602 bytes)
- `0020/PERL_PERSISTENT_SETUP.md` (2464 bytes)
- `0020/QUICK_REFERENCE.md` (3931 bytes)
- `0020/UBUNTU24_COMPATIBILITY_REPORT.md` (4325 bytes)
- `0020/check_available.pl` (1083 bytes)
- `0020/install-persistent-module.pl` (765 bytes)
- `0020/install_minimal_dependencies.ubuntu24.sh` (5514 bytes)
- `0020/perlrc` (247 bytes)
- `0020/protocol-7-clone-summary.txt` (2911 bytes)
- `0020/protocol-7-minimal-test.pl` (2080 bytes)
- `0021/CHECKPOINT_COMPARISON.md` (3676 bytes)
- `0021/RESTORATION_GUIDE.md` (3869 bytes)
- `0021/WORK_ENVIRONMENT_STRATEGY.md` (7363 bytes)
- `0021/checkpoint.sh` (3319 bytes)
- `0021/protocol7_recovered_20250930_1819.tar.gz` (16396 bytes)
- `0021/protocol7_with_strategy_20250930_1834.tar.gz` (17551 bytes)
- `0022/COMPLETE_SUMMARY.md` (13403 bytes)
- `0022/QUICK_REFERENCE_CARD.md` (7746 bytes)
- `0022/WORK_ENVIRONMENT_STRATEGY.md` (7363 bytes)
- `0022/protocol7_ai_native_complete.tar.gz` (32592 bytes)
- `0023/CHECKPOINT_COMPARISON.md` (3676 bytes)
- `0023/COMPLETE_SUMMARY.md` (13403 bytes)
- `0023/QUICK_REFERENCE_CARD.md` (7746 bytes)
- `0023/RESTORATION_GUIDE.md` (3869 bytes)
- `0023/WORK_ENVIRONMENT_STRATEGY.md` (7363 bytes)
- `0023/checkpoint.sh` (3319 bytes)
- `0023/protocol7_ai_native_complete.tar.gz` (32592 bytes)
- `0023/protocol7_recovered_20250930_1819.tar.gz` (16396 bytes)
- `0023/protocol7_with_strategy_20250930_1834.tar.gz` (17551 bytes)
- `0023/test_checkpoint_001.tar.gz` (18668 bytes)
- `0024/protocol7_living_tree_complete.tar.gz` (52655 bytes)
- `0025/ULTIMATE_HARMONIC_SUMMARY.md` (13171 bytes)
- `0025/protocol7_harmonic_complete.tar.gz` (62674 bytes)
- `0026/ULTIMATE_HARMONIC_SUMMARY.md` (13171 bytes)
- `0026/protocol7_harmonic_complete.tar.gz` (62674 bytes)
- `0027/ULTIMATE_HARMONIC_SUMMARY.md` (13171 bytes)
- `0027/protocol7_harmonic_complete.tar.gz` (62674 bytes)
- `0028/CHECKPOINT_COMPARISON.md` (3676 bytes)
- `0028/COMPLETE_SUMMARY.md` (13403 bytes)
- `0028/QUICK_REFERENCE_CARD.md` (7746 bytes)
- `0028/RESTORATION_GUIDE.md` (3869 bytes)
- `0028/ULTIMATE_HARMONIC_SUMMARY.md` (13171 bytes)
- `0028/WORK_ENVIRONMENT_STRATEGY.md` (7363 bytes)
- `0028/checkpoint.sh` (3319 bytes)
- `0028/protocol7_ai_native_complete.tar.gz` (32592 bytes)
- `0028/protocol7_ai_native_with_ephemeral_patterns.tar.gz` (42847 bytes)
- `0028/protocol7_harmonic_complete.tar.gz` (62674 bytes)
- `0028/protocol7_living_tree_complete.tar.gz` (52655 bytes)
- `0028/protocol7_recovered_20250930_1819.tar.gz` (16396 bytes)
- `0028/protocol7_with_strategy_20250930_1834.tar.gz` (17551 bytes)
- `0028/test_checkpoint_001.tar.gz` (18668 bytes)
- `0029/BOOTSTRAP_REFERENCE.md` (1947 bytes)
- `0029/COMPLETE_INTEGRATION_SUMMARY.md` (17031 bytes)
- `0029/PROJECTS_INTEGRATION_GUIDE.md` (15011 bytes)
- `0029/living_tree_base32_complete.tar.gz` (26454 bytes)
- `0029/living_tree_bootstrap.pl` (13906 bytes)
- `0030/COMPLETE_INTEGRATION_SUMMARY.md` (17031 bytes)
- `0030/LIVING_TREE_ARCHIVE.md` (49722 bytes)
- `0030/PROJECTS_QUICK_START.md` (6446 bytes)
- `0030/extract_living_tree.pl` (2867 bytes)
- `0031/BOOTSTRAP_REFERENCE.md` (1947 bytes)
- `0031/COMPLETE_INTEGRATION_SUMMARY.md` (17031 bytes)
- `0031/LIVING_TREE_ARCHIVE.md` (49722 bytes)
- `0031/PROJECTS_INTEGRATION_GUIDE.md` (15011 bytes)
- `0031/PROJECTS_QUICK_START.md` (6446 bytes)
- `0031/extract_living_tree.pl` (2867 bytes)
- `0031/living_tree_base32_complete.tar.gz` (26454 bytes)
- `0031/living_tree_bootstrap.pl` (13906 bytes)
- `0032/INFRASTRUCTURE_CONSTRAINTS_REFERENCE.md` (8656 bytes)
- `0032/INFRASTRUCTURE_RATE_LIMITING.md` (11264 bytes)
- `0032/SELF_EXTRACTOR_README.md` (3616 bytes)
- `0032/SESSION_SUMMARY_SELF_EXTRACTOR.md` (5284 bytes)
- `0032/living_tree_self_extracting.pl` (39670 bytes)
- `0033/INFRASTRUCTURE_CONSTRAINTS_REFERENCE.md` (8656 bytes)
- `0033/INFRASTRUCTURE_RATE_LIMITING.md` (11264 bytes)
- `0033/SELF_EXTRACTOR_README.md` (3616 bytes)
- `0033/SESSION_SUMMARY_SELF_EXTRACTOR.md` (5284 bytes)
- `0033/living_tree_self_extracting.pl` (39670 bytes)
- `0034/GITHUB_PERSISTENCE_GUIDE.md` (10861 bytes)
- `0034/GITHUB_SOLUTION_SUMMARY.md` (13603 bytes)
- `0034/INDEX.md` (8813 bytes)
- `0034/PERSISTENCE_METHODS_COMPARISON.md` (14941 bytes)
- `0034/SETUP_CHECKLIST.md` (9489 bytes)
- `0034/setup_github_persistence.pl` (6448 bytes)
- `0035/GITHUB_PERSISTENCE_GUIDE.md` (10861 bytes)
- `0035/GITHUB_SOLUTION_SUMMARY.md` (13603 bytes)
- `0035/INDEX.md` (8813 bytes)
- `0035/PERSISTENCE_METHODS_COMPARISON.md` (14941 bytes)
- `0035/SETUP_CHECKLIST.md` (9489 bytes)
- `0035/setup_github_persistence.pl` (6448 bytes)
- `0036/GITHUB_PERSISTENCE_GUIDE.md` (10861 bytes)
- `0036/GITHUB_SOLUTION_SUMMARY.md` (13603 bytes)
- `0036/INDEX.md` (8813 bytes)
- `0036/PERSISTENCE_METHODS_COMPARISON.md` (14941 bytes)
- `0036/SETUP_CHECKLIST.md` (9489 bytes)
- `0036/setup_github_persistence.pl` (6448 bytes)
- `0037/GITHUB_WORKSPACE_SUCCESS.md` (9724 bytes)
- `0037/QUICK_REFERENCE.md` (5028 bytes)
- `0037/quick_clone_workspace.pl` (3080 bytes)
- `0037/quick_save_workspace.pl` (2595 bytes)
- `0038/GITHUB_WORKSPACE_SUCCESS.md` (9724 bytes)
- `0038/QUICK_REFERENCE.md` (5028 bytes)
- `0038/generate_base32_archive.pl` (6060 bytes)
- `0038/post-commit-base32-generator.pl` (7913 bytes)
- `0038/quick_clone_workspace.pl` (3080 bytes)
- `0038/quick_save_workspace.pl` (2595 bytes)
- `0039/BMW_RESUMABILITY_TEST_PLAN.md` (5841 bytes)
- `0039/CLAUDE_AI_BMW_TEST_PLAN.md` (2108 bytes)
- `0039/CLAUDE_BMW_TEST_SESSION.md` (1612 bytes)
- `0039/analyze-bmw-implementation.sh` (1590 bytes)
- `0039/test-bmw-resumability.pl` (3600 bytes)
- `ANALYSIS_SUMMARY.md` (4115 bytes)
- `CHECKPOINT_COMPARISON.md` (3676 bytes)
- `CLONED_REPO_ANALYSIS.md` (4720 bytes)
- `COMPLETE_SUMMARY.md` (13403 bytes)
- `INSTALLATION_TEST_RESULTS.md` (6602 bytes)
- `PERL_PERSISTENT_SETUP.md` (2464 bytes)
- `QUICK_REFERENCE.md` (3931 bytes)
- `QUICK_REFERENCE_CARD.md` (7746 bytes)
- `RESTORATION_GUIDE.md` (3869 bytes)
- `UBUNTU24_COMPATIBILITY_REPORT.md` (4325 bytes)
- `WORK_ENVIRONMENT_STRATEGY.md` (7363 bytes)
- `check_available.pl` (1083 bytes)
- `checkpoint.sh` (3319 bytes)
- `install-persistent-module.pl` (765 bytes)
- `install_minimal_dependencies.ubuntu24.sh` (5514 bytes)
- `perlrc` (247 bytes)
- `protocol-7-clone-summary.txt` (2911 bytes)
- `protocol-7-minimal-test.pl` (2080 bytes)
- `protocol7_ai_native_complete.tar.gz` (32592 bytes)
- `protocol7_recovered_20250930_1819.tar.gz` (16396 bytes)
- `protocol7_with_strategy_20250930_1834.tar.gz` (17551 bytes)

---

## 🔄 Files Modified Between Archive and Repository

**Count**: 1 files

- Archive: `0039/CLAUDE_ONBOARDING.md`
  Repo: `CLAUDE_ONBOARDING.md`
  - Archive: 4542 bytes (SHA256: 345d514786442cbe...)
  - Repo: 6234 bytes (SHA256: 210ce4e532a928f6...)

---

## ✅ Files Identical in Both

**Count**: 20 files


---

## Recommendations

1. Review files only in archives for potential recovery
2. Commit valuable content to repository
3. Update documentation if needed
