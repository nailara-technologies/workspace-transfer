package Text::GradualUTF7Compressor;

use strict;
use warnings;
use MIME::Base32 qw(encode_base32 decode_base32);
use Encode qw(encode decode);
use List::Util qw(min);

# Constructor
sub new {
    my ($class, %args) = @_;
    my $self = {
        use_utf7 => $args{use_utf7} // 0,
        level => $args{level} // 'word',
    };
    bless $self, $class;
    return $self;
}

# Perform frequency analysis on the given text
sub frequency_analysis {
    my ($self, $text) = @_;
    my %frequency;

    my @elements;
    if ($self->{level} eq 'character') {
        @elements = split(//, $text);
    } elsif ($self->{level} eq 'syllable') {
        @elements = split(/(?<=\w\w)/, $text);  # Simplified syllable split
    } elsif ($self->{level} eq 'word') {
        @elements = split(/\s+/, $text);
    } elsif ($self->{level} eq 'sentence') {
        @elements = split(/(?<=[.!?])\s*/, $text);
    } elsif ($self->{level} eq 'paragraph') {
        @elements = split(/\n\n+/, $text);
    }

    for my $element (@elements) {
        $frequency{$element}++;
    }

    return \%frequency;
}

# Assign numerical IDs based on frequency
sub assign_ids {
    my ($self, $frequency) = @_;
    my %id_map;
    my $id = 1;

    for my $element (sort { $frequency->{$b} <=> $frequency->{$a} } keys %$frequency) {
        my $encoded_id = $self->{use_utf7} ? encode('UTF-7', chr(10000 + $id)) : $id;
        $id_map{$element} = $encoded_id;
        $id++;
    }

    return \%id_map;
}

# Compare and encode if shorter
sub encode_if_shorter {
    my ($self, $element, $encoded_id) = @_;
    if (length($encoded_id) < length($element)) {
        return $encoded_id;
    }
    return $element;
}

# Compress the text using the assigned numerical IDs
sub compress_text {
    my ($self, $text, $id_map) = @_;
    my @words = split(/\s+/, $text);
    my @compressed;

    for my $word (@words) {
        my $encoded_word = $id_map->{$word} // $word;
        if ($self->{use_utf7} && $encoded_word =~ /^\d+$/) {
            $encoded_word = $self->encode_if_shorter($word, encode('UTF-7', chr(10000 + $encoded_word)));
        }
        push @compressed, $encoded_word;
    }

    return join(' ', @compressed);
}

# Expand the compressed text back to its original form
sub expand_text {
    my ($self, $compressed_text, $id_map) = @_;
    my %reverse_id_map = reverse %$id_map;
    my @words = split(/\s+/, $compressed_text);
    my @expanded;

    for my $word (@words) {
        my $decoded_word;
        if ($self->{use_utf7} && $word =~ /^\+/) {
            $decoded_word = ord(decode('UTF-7', $word)) - 10000;
        } else {
            $decoded_word = $word;
        }
        push @expanded, $reverse_id_map{$decoded_word} // $word;
    }

    return join(' ', @expanded);
}

1;