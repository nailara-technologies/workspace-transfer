package Text::HarmonizedChecksums;

use strict;
use warnings;
use Digest::BMW;
use Digest::Elf qw(elf);
use Crypt::Misc qw(encode_b32r decode_b32r);
use Math::BigFloat;

# Constructor
sub new {
    my ($class, %args) = @_;
    my $self = {};
    bless $self, $class;
    return $self;
}

# Apply BMW checksum and encode in Base32
sub bmw_base32 {
    my ($self, $message) = @_;
    my $bmw = Digest::BMW->new(512);
    $bmw->add($message);
    my $checksum = $bmw->digest;
    return encode_b32r($checksum);
}

# Apply AMOS7 for 7-digit or less
sub amos7 {
    my ($self, $message) = @_;
    my $checksum = substr($message, 0, 7);
    return $checksum;
}

# Apply ELF7 for numerical mappings
sub elf7 {
    my ($self, $message) = @_;
    my $elf_value = elf($message);
    return substr($elf_value, 0, 7);
}

# Determine the appropriate checksum type
sub harmonized_checksum {
    my ($self, $message) = @_;
    if ($message =~ /^\d+$/) {
        return $self->elf7($message);
    } elsif (length($message) <= 7) {
        return $self->amos7($message);
    } else {
        return $self->bmw_base32($message);
    }
}

1;