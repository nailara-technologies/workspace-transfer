package Text::CleanDecoder;

use strict;
use warnings;
use Math::BigFloat;
use Encode qw(decode);
use Term::ANSIColor;

# Constructor
sub new {
    my ($class, %args) = @_;
    my $self = {
        seed => $args{seed} // '4085077156245892212221638888445691017681238712064386070392685102677',
        screen_size => $args{screen_size} // [80, 24],
        screen_chars => $args{screen_chars} // 80 * 24,
    };
    bless $self, $class;
    return $self;
}

# Perform division by 13 until the numerical result is fully decoded or exhausted
sub decode_number {
    my ($self, $number) = @_;
    my $big_number = Math::BigFloat->new($number);
    my $decoded_message = '';

    while ($big_number > 0) {
        my $result = $big_number->bdiv(13);
        my $char_code = $result->bfloor()->bstr();
        last if $char_code <= 0;
        
        # Decode the character
        my $character = chr($char_code);
        $decoded_message .= $character;

        # Update the big number for next iteration
        $big_number = $result->bmod(1)->bmul(13);
    }

    return $decoded_message;
}

# Analyze the decoded segments using a triple buffer
sub analyze_segments {
    my ($self, $segments) = @_;
    my @triple_buffer = ('', '', '');
    my $decoded_message = '';

    foreach my $segment (@$segments) {
        shift @triple_buffer;
        push @triple_buffer, $segment;

        # Analyze the triple buffer
        my $analysis = join('', @triple_buffer);
        $decoded_message .= $analysis;
    }

    return $decoded_message;
}

# Main decoding function
sub decode {
    my ($self) = @_;
    my $number = $self->{seed};
    my $decoded_segments = [];

    while (length($number) > 0) {
        my $decoded_segment = $self->decode_number($number);
        push @$decoded_segments, $decoded_segment;

        # Update the number for next iteration
        $number = substr($number, length($decoded_segment));
    }

    my $final_message = $self->analyze_segments($decoded_segments);
    return $final_message;
}

1;