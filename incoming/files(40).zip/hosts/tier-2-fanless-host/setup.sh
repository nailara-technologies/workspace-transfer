#!/bin/bash
# Fanless host complete setup

set -e

echo "=== Fanless Host Setup ==="

# 1. Ollama
if ! command -v ollama &>/dev/null; then
    echo "[1/6] Installing Ollama..."
    curl -fsSL https://ollama.com/install.sh | sh
    
    # Pull model
    ollama pull qwen2.5-coder:32b
else
    echo "[1/6] Ollama already installed"
fi

# 2. photonic-desktop
if [ ! -d ~/photonic-desktop ]; then
    echo "[2/6] Cloning photonic-desktop..."
    cd ~
    git clone https://github.com/nailara-technologies/photonic-desktop.git
else
    echo "[2/6] photonic-desktop already present"
fi

# 3. Protocol-7
if [ ! -d ~/protocol-7 ]; then
    echo "[3/6] Cloning Protocol-7..."
    cd ~
    git clone https://github.com/nailara-technologies/protocol-7.git
else
    echo "[3/6] Protocol-7 already present"
fi

# 4. workspace-transfer (if not already cloned)
if [ ! -d ~/workspace-transfer ]; then
    echo "[4/6] Cloning workspace-transfer..."
    cd ~
    git clone https://github.com/nailara-technologies/workspace-transfer.git
else
    echo "[4/6] workspace-transfer already present"
fi

# 5. Workspace directories
echo "[5/6] Creating workspace directories..."
mkdir -p ~/work ~/outputs

# 6. Wake-on-LAN
echo "[6/6] Configuring Wake-on-LAN..."
INTERFACE=$(ip route | grep default | awk '{print $5}' | head -n1)
if [ -n "$INTERFACE" ]; then
    ethtool -s "$INTERFACE" wol g 2>/dev/null || echo "  WoL not supported"
fi

echo ""
echo "✅ Fanless host setup complete!"
echo ""
echo "Next: cd ~/workspace-transfer/incoming && extract archives (Phase 0)"