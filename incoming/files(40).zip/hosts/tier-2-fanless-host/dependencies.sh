#!/bin/bash
# Fanless host dependencies
# Full Protocol-7 + desktop environment

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Download Protocol-7 dependency scripts
echo "Fetching Protocol-7 dependencies..."
cd /tmp
wget -q https://raw.githubusercontent.com/nailara-technologies/protocol-7/base/bin/dependencies/install_minimal_dependencies.debian.sh
wget -q https://raw.githubusercontent.com/nailara-technologies/protocol-7/base/bin/dependencies/install_dependencies.debian.sh

chmod +x install_*.sh

echo "Installing minimal dependencies..."
./install_minimal_dependencies.debian.sh

echo "Installing full dependencies..."
./install_dependencies.debian.sh

# Cleanup
rm install_*.sh

echo "✅ Dependencies installed"