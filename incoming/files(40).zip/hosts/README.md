# Nailara Technologies - Host Infrastructure

## Three-Tier Architecture

### Tier 1: Main Desktop (High Performance)
- **Purpose**: Heavy development, compilation, GPU passthrough
- **Power**: 150-300W active, 0W standby (WoL enabled)
- **OS**: Debian 12 + photonic-desktop
- **Setup**: `./hosts/deploy-host.sh` → Select option 1

### Tier 2: Fanless Host (Always-On Development)
- **Purpose**: 24/7 development, Ollama LLM, Protocol-7 core
- **Power**: 15-35W continuous
- **OS**: Debian 12 + photonic-desktop (minimal)
- **Setup**: `./hosts/deploy-host.sh` → Select option 2

### Tier 3: Raspberry Pi (Low-Power Orchestrator)
- **Purpose**: WoL controller, monitoring, graceful degradation
- **Power**: 5-8W continuous
- **OS**: Debian 12 ARM64 or Raspberry Pi OS
- **Setup**: `./hosts/deploy-host.sh` → Select option 3

## Quick Start

```bash
# Clone workspace-transfer
git clone https://github.com/nailara-technologies/workspace-transfer.git
cd workspace-transfer

# Deploy any tier
sudo ./hosts/deploy-host.sh
```

## Directory Structure

```
hosts/
├── common/              # Shared across all tiers
├── tier-1-main-desktop/ # High-performance workstation
├── tier-2-fanless-host/ # Always-on development
├── tier-3-raspberry-pi/ # Low-power orchestrator
└── network/             # Network configuration
```

## Recovery

If any host fails, redeploy from this repository:
1. Fresh Debian installation
2. Clone this repo
3. Run `./hosts/deploy-host.sh`
4. Select appropriate tier

**Nothing is ever lost - everything is version controlled.**