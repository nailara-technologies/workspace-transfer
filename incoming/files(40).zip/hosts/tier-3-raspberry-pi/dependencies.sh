#!/bin/bash
# Raspberry Pi minimal dependencies

set -e

cd /tmp
wget -q https://raw.githubusercontent.com/nailara-technologies/protocol-7/base/bin/dependencies/install_minimal_dependencies.debian.sh

chmod +x install_minimal_dependencies.debian.sh
./install_minimal_dependencies.debian.sh

# Wake-on-LAN tools
apt-get install -y wakeonlan etherwake

rm install_minimal_dependencies.debian.sh

echo "✅ Raspberry Pi dependencies installed"