#!/bin/bash
# Wake main desktop

DESKTOP_MAC="11:22:33:44:55:66"  # TODO: Update with actual MAC
DESKTOP_IP="192.168.1.10"

echo "🔌 Waking main desktop..."
wakeonlan $DESKTOP_MAC

# Wait for boot
for i in {1..60}; do
    if ping -c 1 $DESKTOP_IP &>/dev/null; then
        echo "✅ Main desktop is up!"
        exit 0
    fi
    sleep 2
done

echo "⚠️  Timeout waiting for main desktop"
exit 1