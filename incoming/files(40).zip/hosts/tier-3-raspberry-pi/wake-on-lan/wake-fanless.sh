#!/bin/bash
# Wake fanless host

FANLESS_MAC="AA:BB:CC:DD:EE:FF"  # TODO: Update with actual MAC
FANLESS_IP="192.168.1.20"

echo "🔌 Waking fanless host..."
wakeonlan $FANLESS_MAC

# Wait for boot
for i in {1..30}; do
    if ping -c 1 $FANLESS_IP &>/dev/null; then
        echo "✅ Fanless host is up!"
        exit 0
    fi
    sleep 2
done

echo "⚠️  Timeout waiting for fanless host"
exit 1