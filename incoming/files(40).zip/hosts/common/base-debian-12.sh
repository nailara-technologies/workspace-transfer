#!/bin/bash
# Common Debian 12 baseline setup
# Used by all tiers

set -e
set -u

GREEN='\033[0;32m'
NC='\033[0m'
info() { echo -e "${GREEN}[INFO]${NC} $*"; }

info "Updating system packages..."
apt-get update
apt-get upgrade -y

info "Installing essential tools..."
apt-get install -y \
    curl wget git vim nano \
    htop ncdu tree tmux \
    openssh-server \
    build-essential \
    ethtool net-tools \
    rsync unzip zip

info "Configuring SSH server..."
systemctl enable ssh
systemctl start ssh

info "Base Debian 12 setup complete"