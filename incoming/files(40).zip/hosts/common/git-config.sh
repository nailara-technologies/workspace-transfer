#!/bin/bash
# Git configuration with Nailara defaults

set -e

read -p "Git username [nailara]: " git_user
git_user=${git_user:-nailara}

read -p "Git email [nailara@protocol-7.com]: " git_email
git_email=${git_email:-nailara@protocol-7.com}

git config --global user.name "$git_user"
git config --global user.email "$git_email"
git config --global init.defaultBranch base
git config --global core.editor vim

echo "✅ Git configured for $git_user <$git_email>"